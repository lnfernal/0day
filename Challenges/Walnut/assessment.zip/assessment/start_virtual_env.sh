#!/bin/bash

pipenv --three
pipenv install flask
pipenv install Flask-Caching
pipenv install aiohttp
