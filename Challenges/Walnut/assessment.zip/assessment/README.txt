Installation:
You'll need pipenv,
$ pip3 install pipenv

To download all dependencies, I wrote a small bash script which does all the work for you
$ ./start_virtual_env

Usage:
To start the Flask app, run bootstrap.sh
$ ./bootstrap.sh
This automatically listens on port 5000